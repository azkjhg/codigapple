import React from "react";

const page = () => {
  return (
    <div>
      <input type="file"></input>
      <button type="submit" onClick={upload}>
        버튼
      </button>
    </div>
  );
};

export default page;
