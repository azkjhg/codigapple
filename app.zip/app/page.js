// "use client";
import { connectDB } from "@/util/database";
import { MongoClient } from "mongodb";
import Image from "next/image";

export default async function Home() {
  return <>안녕</>;
}
